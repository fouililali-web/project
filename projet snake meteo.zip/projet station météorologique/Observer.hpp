#ifndef OBSERVER_HPP
#define OBSERVER_HPP

class Observer {
public:
    virtual void update(float t, float h, float p) = 0;
};

#endif
