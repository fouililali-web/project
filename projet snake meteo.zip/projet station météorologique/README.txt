Mini Projet 2 - Station Météorologique
Description:
Ce projet utilise le design pattern Observer.
DonneesMeteo notifie automatiquement les affichages:
- Conditions actuelles
- Statistiques
- Prévisions

Compilation:
g++ main.cpp DonneesMeteo.cpp -o meteo

Execution:
./meteo