#include "DonneesMeteo.hpp"
#include "Affichages.hpp"

int main(){
    DonneesMeteo station;

    ConditionsActuelles c1;
    Statistiques c2;
    Previsions c3;

    station.registerObserver(&c1);
    station.registerObserver(&c2);
    station.registerObserver(&c3);

    station.setMesures(25, 60, 1013);
    station.setMesures(30, 70, 1008);

    return 0;
}
