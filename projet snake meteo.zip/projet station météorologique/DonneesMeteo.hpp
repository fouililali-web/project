#ifndef DONNEESMETEO_HPP
#define DONNEESMETEO_HPP

#include <vector>
#include "Observer.hpp"

class DonneesMeteo {
private:
    std::vector<Observer*> observers;
    float temperature, humidity, pressure;

public:
    void registerObserver(Observer* o);
    void notifyObservers();
    void setMesures(float t, float h, float p);
};

#endif
