#ifndef AFFICHAGES_HPP
#define AFFICHAGES_HPP

#include <iostream>
#include "Observer.hpp"

/* Conditions */
class ConditionsActuelles : public Observer {
public:
    void update(float t, float h, float p) override {
        std::cout << "Temp: " << t << " Hum: " << h << std::endl;
    }
};

/* Stats */
class Statistiques : public Observer {
public:
    void update(float t, float h, float p) override {
        std::cout << "Stats Temp: " << t << std::endl;
    }
};

/* Forecast */
class Previsions : public Observer {
public:
    void update(float t, float h, float p) override {
        std::cout << "Forecast..." << std::endl;
    }
};

#endif
