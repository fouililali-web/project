#include "DonneesMeteo.hpp"

void DonneesMeteo::registerObserver(Observer* o){
    observers.push_back(o);
}

void DonneesMeteo::notifyObservers(){
    for(auto o : observers)
        o->update(temperature, humidity, pressure);
}

void DonneesMeteo::setMesures(float t, float h, float p){
    temperature = t;
    humidity = h;
    pressure = p;
    notifyObservers();
}
