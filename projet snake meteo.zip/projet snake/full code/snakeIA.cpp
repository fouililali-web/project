#include "snakeIA.hpp"
#include <map>
#include <vector>
#include <limits>
#include <cmath>
#include <algorithm>

/* ================= Constructor ================= */
SnakeAI::SnakeAI(int pos_x, int pos_y, int taille_x, int taille_y)
    : Snake(pos_x, pos_y, taille_x, taille_y)
{
}

/* ================= Initialize INF grid ================= */
void SnakeAI::constructInf(std::map<std::pair<float, float>, float> &g)
{
    for(int i = 0; i < this->taille_X; i += 10)
    {
        for(int j = 0; j < this->taille_Y; j += 10)
        {
            g[std::make_pair((float)i, (float)j)] =
                std::numeric_limits<float>::max();
        }
    }
}

/* ================= A* (simplified corrected version) ================= */
char SnakeAI::astar(float x, float y)
{
    std::vector<std::pair<float, float>> openSet;
    openSet.push_back({x, y});

    std::map<std::pair<float, float>, std::pair<float, float>> cameFrom;
    std::map<std::pair<float, float>, float> gScore;
    std::map<std::pair<float, float>, float> fScore;

    constructInf(gScore);
    constructInf(fScore);

    gScore[{x, y}] = 0;
    fScore[{x, y}] = 0;

    std::pair<float, float> current = {x, y};

    while (!openSet.empty())
    {
        current = openSet.back();
        openSet.pop_back();

        // Goal reached (simplified condition)
        if (current.first == x && current.second == y)
        {
            if (cameFrom.find(current) == cameFrom.end())
                return 'U';

            auto prev = cameFrom[current];

            if (prev.first < current.first) return 'R';
            if (prev.first > current.first) return 'L';
            if (prev.second < current.second) return 'D';
            if (prev.second > current.second) return 'U';
        }

        std::vector<std::pair<float, float>> neigh = {
            {x - 10, y},
            {x + 10, y},
            {x, y - 10},
            {x, y + 10}
        };

        for (auto &n : neigh)
        {
            float tentative = gScore[current] + 1;

            if (tentative < gScore[n])
            {
                cameFrom[n] = current;
                gScore[n] = tentative;
                fScore[n] = tentative + 1;

                openSet.push_back(n);
            }
        }
    }

    return 'U'; // default safe move
}

/* ================= MOVE (NOT IMPLEMENTED YET) ================= */
void SnakeAI::move(float x, float y, Snake &s)
{
    // TODO: use astar() result to move snake
}
